param(
    [Parameter(Mandatory=$true)]
    [string]$ServerUrl,

    [Parameter(Mandatory=$true)]
    [string]$ApiKey,

    [Parameter(Mandatory=$false)]
    [string]$FilePath = ".\*.txt"
)

$headers = @{
    "x-api-key" = $ApiKey
}

Get-ChildItem -Path $FilePath | ForEach-Object {
    $filePath = $_.FullName
    $fileName = $_.Name
    
    try {
        $fileForm = @{
            file = Get-Item $filePath
        }

        Invoke-RestMethod -Uri $ServerUrl `
            -Method Post `
            -Headers $headers `
            -Form $fileForm `
            -ContentType "multipart/form-data"
    }
    catch {
    }
}
