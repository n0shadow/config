$appDataPath = "$env:LOCALAPPDATA\Server\Core"
$argumentos = "server.js"
Start-Process -FilePath "node.exe" -ArgumentList $argumentos -WorkingDirectory $appDataPath -WindowStyle Hidden